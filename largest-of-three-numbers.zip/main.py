n=int(input())
if (n%2!=0):
    print("prime")
else:
    print("not prime")