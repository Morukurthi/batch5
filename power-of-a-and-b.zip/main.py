def power(a,b):
    if b==1:
        return a
    else:
        return a*(power(a,b-1))
base=int(input())
exp=int(input())
print(power(base,exp))      
    
    
